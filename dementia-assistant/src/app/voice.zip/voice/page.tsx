export const dynamic = "force-dynamic";
export default function VoiceIndex() {
  return <div style={{padding:24}}>✅ /voice index route is mounted</div>;
}
